package sse.hust.vini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViniApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViniApplication.class, args);
	}

}
